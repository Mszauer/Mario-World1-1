NAudio is an open source .NET audio library written by Mark Heath (mark.heath@gmail.com)
For more information, visit http://naudio.codeplex.com

THANKS
======
The following list includes some of the people who have contributed in various ways to NAudio, such as code contributions,
bug fixes, documentation, helping out on the forums and even donations. I haven't finished compiling this list yet, so
if your name should be on it but isn't please let me know and I will include it. Also, some people I only know by their forum
id, so if you want me to put your full name here, please also get in touch.

in alphabetical order:
Alan Jordan
Alexandre Mutel
Alexander Binkert
AmandaTarafaMas
balistof
biermeester
borman11
bradb
Brandon Hansen (kg6ypi)
csechet
ChunkWare Music Software
CKing
DaMacc
Du10
eejake52
Florian Rosmann (filoe)
Giawa
Harald Petrovitsch
Hfuy
Iain McCowan
Idael Cardaso 
ioctlLR
Jamie Michael Ewins
jannera
jbaker8935
jcameron23
JoeGaggler
jonahoffmann
jontdelorme
Justin Frankel
K24A3
Kassoul
kevinxxx
kzych
LionCash
Lustild
Lucian Wischik (ljw1004)
ManuN
MeelMarcel
Michael Chadwick
Michael Feld 
Michael J
Michael Lehenbauer
milligan22963
myrkle
nelsonkidd
Nigel Redmon
Nikolaos Georgiou
Owen Skriloff
owoudenb
painmailer
PPavan
Pygmy
Ray Molenkamp
Roadz
Robert Bristow-Johnson
Scott Fleischman 
Simon Clark
Sirish Bajpai
sporn
Steve Underwood
Ted Murphy
Tiny Simple Tools
Tobias Fleming
TomBogle
Tony Cabello
Tony Sistemas
TuneBlade
topher3683
volmart
Vladimir Rokovanov
Ville Koskinen
Wyatt Rice
Yuval Naveh
Zsb
